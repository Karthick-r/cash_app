<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Model\Admin\store;
use App\Model\Admin\route;
use App\Model\Admin\routes_stores;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\View;
use Validator;
use App\Model\Admin\relationship;

class StoreAllocation extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $store=store::where('deleted_on_off', '1')->with('route_store')->get();
        
        //echo $store;//
        return view('admin/storeallocation/index',['store'=>$store]);  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $store = store::with('route_store')->find($id);
      $route=route::where('deleted_on_off', '1')->get();
           // echo $users;
             //return response()->json($users); 
      return View('admin.storeallocation.edit1',['store'=>$store,'route'=>$route]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $store = store::find($id);
      $route=route::where('deleted_on_off', '1')->get();
           // echo $users;
             //return response()->json($users); 
      return View('admin.storeallocation.edit',['store'=>$store,'route'=>$route]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $this->validate($request,
       
        [
         'route_id' => 'required',
        ]); 

            $store = store::find($id);           
            $store->route_id=$request->input('route_id');     
            $store->updated_at= new \DateTime();
            $store->save(); 
            $notification = array(
            'message' => 'Your date is updated', 
            'alert-type' => 'success');
            return Redirect::to('storeallocation')->with($notification);
    }


     public function update1(Request $request, $id)
    {
       
$this->validate($request,
       
        [
         'route_id' => 'required',
       
 
        ]); 

            $store = store::find($id); 
            $store->route_id=$request->input('route_id');     
            $store->updated_at= new \DateTime();
            $store->save();


            $notification = array(
            'message' => 'Your date is updated', 
            'alert-type' => 'success');
            return Redirect::to('storeallocation')->with($notification);


    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
