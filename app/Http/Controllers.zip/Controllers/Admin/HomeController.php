<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Http\Requests;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.home');
    }

    public function notification()
    {
        $notification = array(
            'message' => 'Thanks! We shall get back to you soon.', 
            'alert-type' => 'info'
        );

        session(['notification' => $notification]);
        //session()->set('notification',$notification);
        return view('notification');
    }
}
