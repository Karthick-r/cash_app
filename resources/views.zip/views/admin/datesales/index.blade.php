@extends('admin.layout.app')
 

@section('main-content')

   <section id="dom">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="card-title">Date Range Report</h4>



                  <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                  <div class="heading-elements" style="top:11px;">
                    <ul class="list-inline mb-0">
                   <li> 
                   <div class="col-sm-12">

                        <form method="post" action="{{ url('datesales/date_range') }}">

                          {{ csrf_field() }}

                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">
                              <span class="fa fa-calendar-o"></span>
                            </span>
                          </div>
                          <input type='text' class="form-control showdropdowns"  name="dates" placeholder="{{date('d F,Y')}}"
                          />

                           <input type="submit" value="Filter" name=""  style="margin-left: 25px" class="btn btn-info">
                        
                        </div>
                       </form>
                       </div>
                      </li>
                      
                    
                    </ul>
                  </div>
                </div>
                </div>
                </div>
                </div>
                </section>


<div class="row">
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card">
            <div class="card-body">
                <div class="card-block">
                    <div class="media">
                        <div class="media-body text-xs-left">
                                
                            <h3 class="pink">
                          54
                            </h3>


                            <span>All Compliants</span>
                        </div>
                        <div class="media-right media-middle">
                            <i class="icon-bag2 pink font-large-2 float-xs-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card">
            <div class="card-body">
                <div class="card-block">
                    <div class="media">
                        <div class="media-body text-xs-left">
                                <h3 class="deep-orange">54</h3>
                                <span>Total users Registered</span>
                        </div>
                        <div class="media-right media-middle">
                            <i class="icon-user1 teal font-large-2 float-xs-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card">
            <div class="card-body">
                <div class="card-block">
                    <div class="media">
                        <div class="media-body text-xs-left">
                                <h3 class="cyan">54</h3>
                                <span>Total Admins</span>
                        </div>
                        <div class="media-right media-middle">
                            <i class="icon-diagram deep-orange font-large-2 float-xs-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card">
            <div class="card-body">
                <div class="card-block">
                    <div class="media">
                        <div class="media-body text-xs-left">
                            <h3 class="cyan"> 65 </h3>
                            <span>Upcoming Events</span>
                        </div>
                        <div ">
                            <i  font-large-2 float-xs-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

     
     <section id="dom">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="card-title">Daily Report</h4>
                 
                     

                 
                  <div class="heading-elements">
                    <ul class="list-inline mb-0">
                   
                      <li>
 

                       </li>
                      <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                      <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                      <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                      <li><a data-action="close"><i class="ft-x"></i></a></li>
                    
                    </ul>
                  </div>
                </div>
                <div class="card-content collapse show">
                  <div class="card-body card-dashboard">
                    
            
                 <table  class="table table-striped table-bordered zero-configuration">
                <thead>
                <tr>
                <th>#</th>
                  <th>Shop-Name</th> 
                  <th>Route-Name</th>
                  <th>O.R</th>
                  <th>C.R</th> 
                  <th>M.R</th> 
                  <th>T.R</th>
                  <th>O.R</th>
                  <th>C.R</th> 
                  <th>M.R</th>  
                  <th>T.R</th>
                  <th>Salary</th>
                  <th>Cash</th>
            
                </tr>
                </thead>
                <tbody>
                <?php $i=1;?>
                @foreach($reading as $reading)
                <tr>
                <td>{{ $i }}
         <?php $i++;?>
                </td>
          <td>ID{{$reading->reading_store1->store_id}} {{$reading->reading_store1->store_name}}</td>
          <td><a> {{$reading->reading_route1->route_name}}  </a></td>
          <td><a><?php $open=$reading->water_reading-$reading->today_water_reading; ?></a>{{$open}}</td>
          <td><a>{{$reading->water_reading}}</a></td>
          <td><a>{{$reading->water_maintance_reading}}</a></td>
          <td><a>{{$reading->today_water_reading}}</a></td>


          <td><a><?php $open1= $reading->bottle_reading-$reading->today_bottle_reading; ?></a>{{$open1}}</td>
          <td><a>{{$reading->bottle_reading}}</a></td>
          <td><a>{{$reading->bottle_maintance_reading}}</a></td>
          <td><a>{{$reading->bottle_today_reading}}</a></td>  

 <td><a>{{$reading->salary}}</a></td>  

 <td><a href="" data-toggle="modal" data-target="#default{{$reading->reading_id}}">{{$reading->cash_collect}}</a></td>  

      

                 
                </tr>

 
                    <div class="modal fade text-left" id="default{{$reading->reading_id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1"
                          aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h4 class="modal-title" id="myModalLabel1">Denomination</h4>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                              
                                @foreach($denominations as $denomination)

                                @if($reading->reading_id==$denomination->reading_id)
                             <div class="modal-body">
                          <h5><b>2000</b>:{{ $denomination->rs_2000}}</h5>
                          <h5><b>500</b>:{{ $denomination->rs_500}}</h5>
                          <h5><b>200</b>:{{ $denomination->rs_200}}</h5>
                          <h5><b>100</b>:{{ $denomination->rs_100}}</h5>
                          <h5><b>20</b>:{{ $denomination->rs_20}}</h5>
                          <h5><b>10</b>:{{ $denomination->rs_10}}</h5>
                          <h5><b>5</b>:{{ $denomination->rs_5}}</h5>
                          <h5><b>2</b>:{{ $denomination->rs_2}}</h5>
                          <h5><b>1</b>:{{ $denomination->rs_1}}</h5>
                                </div>
                                @endif
                                 @endforeach
                                <div class="modal-footer">
                                  <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Close</button>
                                 
                                </div>
                              </div>
                            </div>
                          </div>
                 @endforeach
              
              
                </tbody>
              
              </table>
                
             </div>
                </div>
              </div>
            </div>
          </div>
        </section>

 <div id="div_hidden">
                  
<input id="picker_from"  class="form-control datepicker" type="hidden">
<input id="picker_to" class="form-control datepicker" type="hidden">
       
    </div>

<script>
document.getElementById("div_hidden").style.display = "none";
</script>
     
@endsection