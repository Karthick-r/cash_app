@extends('admin.layout.app')
 

@section('main-content')
     
     <section id="dom">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="card-title">Store Allocation</h4>



                  <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                  <div class="heading-elements">
                    <ul class="list-inline mb-0">
                   
                   <li>
                 

                   </li>
                      <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                      <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                      <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                      <li><a data-action="close"><i class="ft-x"></i></a></li>
                    </ul>
                  </div>
                </div>
                <div class="card-content collapse show">
                  <div class="card-body card-dashboard">
                    
            
                 <table  class="table table-striped table-bordered zero-configuration">
                <thead>
                <tr>
                <th>#</th>
                  <th>Store Name</th>       
                  <th>Route Name</th>
                 
                
                  <th>Action</th>
            
      
                </tr>
                </thead>
                <tbody>
                <?php $i=1;?>
                @foreach($store as $stores)
                <tr>
                <td>{{ $i }}
         <?php $i++;?>
                </td>
                  <td>{{$stores->store_name}}</td>
              
                  <td>
                  @if($stores->route_id!=0)
                    {{$stores->route_store->route_name}}
                  @else
<a href="{{ route('storeallocation.edit',$stores->store_id ) }}" class="btn btn-success">
                            Not allocated
                                        </a>
                  @endif</td>
              
                 
                  <td>

  @if($stores->route_id==0)
  <a href="{{ route('storeallocation.edit',$stores->store_id ) }}" class="btn btn-success">
                            Not allocated
                                        </a>
                                        @else

    <a href="{{ route('storeallocation.show',$stores->store_id ) }}" class="btn  btn-primary">
                            <i class="fa fa-pencil"></i>
                                        </a>
                                        @endif


                 
                    

                  </td>

                 
                </tr>
                 @endforeach
              
              
                </tbody>
              
              </table>
                
             </div>
                </div>
              </div>
            </div>
          </div>
        </section>


<script>
  function clickAlert() {
   var result = confirm("Are you sure want to delete");
    if(result ) 
    { 
     return true;
    } 
   else
   {
    return false;
   }
}
</script>

            <!-- Default box -->


     
@endsection