  <div class="main-menu menu-fixed menu-dark menu-accordion    menu-shadow " data-scroll-to-active="true">
    <div class="main-menu-content">
      <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
<li class=" nav-item {{ Request::is('home') ? 'active' : '' }}"><a href="{{ url('/home') }}"><i class="icon-home"></i><span class="menu-title" data-i18n="nav.users.main">Dashboard</span></a></li>

 
       <li class=" nav-item "><a href="#"><i class="icon-layers"></i><span class="menu-title" data-i18n="nav.page_layouts.main">Master</span></a>
              <ul class="menu-content">
                <li class="{{ Request::is('employe') ? 'active' : '' }}"><a class="menu-item " href="{{ url ('employe') }}" data-i18n="nav.page_layouts.1_column">Employe</a>
            </li>
            

              <li class="{{ Request::is('store') ? 'active' : '' }}">
              <a class="menu-item" href="{{ url ('store') }}" data-i18n="nav.page_layouts.2_columns">Store</a>
            </li>

               
                  <li class="{{ Request::is('route') ? 'active' : '' }}">
              <a class="menu-item" href="{{ url ('route') }}" data-i18n="nav.page_layouts.2_columns">Route</a>
            </li>

                   <li class="{{ Request::is('expensive_category') ? 'active' : '' }}">
              <a class="menu-item" href="{{ url ('expensive_category') }}" data-i18n="nav.page_layouts.2_columns">Expense Category</a>
            </li>



              </ul>
            </li>


             <li class=" nav-item "><a href="#"><i class="icon-layers"></i><span class="menu-title" data-i18n="nav.page_layouts.main">Allocation</span></a>
              <ul class="menu-content">
                <li class="{{ Request::is('routeallocation') ? 'active' : '' }}"><a class="menu-item " href="{{ url ('routeallocation') }}" data-i18n="nav.page_layouts.1_column">Allocation Route</a>
            </li>
            

              <li class="{{ Request::is('storeallocation') ? 'active' : '' }}">
              <a class="menu-item" href="{{ url ('storeallocation') }}" data-i18n="nav.page_layouts.2_columns">Allocation Store</a>
            </li>

               
                  

              </ul>
            </li>






           <li class=" nav-item {{ Request::is('details') ? 'active' : '' }}"><a href="{{ url ('details') }}"><i class="icon-layers"></i><span class="menu-title" data-i18n="nav.changelog.main">Route</span></a>
          </li> 





           <li class=" nav-item {{ Request::is('price') ? 'active' : '' }}"><a href="{{ url ('price') }}"><i class="icon-layers"></i><span class="menu-title" data-i18n="nav.changelog.main">Price</span></a>
          </li> 
     
       <li class=" nav-item {{ Request::is('firstreading') ? 'active' : '' }}"><a href="{{ url ('firstreading') }}"><i class="icon-layers"></i><span class="menu-title" data-i18n="nav.changelog.main">FirstReading</span></a>
          </li> 


          <li class=" nav-item "><a href="#"><i class="icon-layers"></i><span class="menu-title" data-i18n="nav.page_layouts.main">Report</span></a>
              <ul class="menu-content">
                <li class="{{ Request::is('report') ? 'active' : '' }}"><a class="menu-item " href="{{ url ('report') }}" data-i18n="nav.page_layouts.1_column">Daily Report</a>
            </li>
            

              <li class="{{ Request::is('datesales') ? 'active' : '' }}">
              <a class="menu-item" href="{{ url ('datesales') }}" data-i18n="nav.page_layouts.2_columns">Date Range Sales</a>
            </li>

                  <li class="{{ Request::is('storesales') ? 'active' : '' }}">
              <a class="menu-item" href="{{ url ('storesales') }}" data-i18n="nav.page_layouts.2_columns">Store Wise Sales</a>
            </li>
                  <li class="{{ Request::is('expanse') ? 'active' : '' }}">
              <a class="menu-item" href="{{ url ('expanse') }}" data-i18n="nav.page_layouts.2_columns">Expense</a>
            </li>

              </ul>
            </li>



      </ul>
    </div>
  </div>