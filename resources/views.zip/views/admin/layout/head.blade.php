


<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <meta name="author" content="PIXINVENT">
  <title>Dashboard  -Cash-app</title>
  <link rel="apple-touch-icon" href="{{asset('logos/maxresdefault.jpg')}}">
  <link rel="shortcut icon" type="image/x-icon" href="{{asset('admin/images/backgrounds/bg-2-block.jpg')}}">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,400,500,700"
  rel="stylesheet">

  <link rel="stylesheet" type="text/css" href="{{asset('admin/css/vendors.css')}}">

   <link rel="stylesheet" type="text/css" href="{{asset('admin/vendors/css/pickers/daterange/daterangepicker.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('admin/vendors/css/pickers/pickadate/pickadate.css')}}">


  <link rel="stylesheet" type="text/css" href="{{asset('admin/vendors/css/tables/datatable/datatables.min.css') }}">
  <link rel="stylesheet" type="text/css" href="{{asset('admin/css/app.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('admin/css/core/menu/menu-types/vertical-menu.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('admin/css/core/colors/palette-gradient.css')}}">

  <link rel="stylesheet" type="text/css" href="{{asset('admin/css/plugins/pickers/daterange/daterange.css')}}">

  <link rel="stylesheet" type="text/css" href="{{asset('admin/assets/css/style.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('admin/toastr/toastr.css')}}">
 


</head>

  @section('head')
            

                  @show

</head>




